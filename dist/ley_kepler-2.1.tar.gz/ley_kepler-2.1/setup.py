from setuptools import setup

setup(
    name='ley_kepler',
    version=2.1,
    description='This module calculate kepler',
    author='JDLV',
    author_email="jdlv@gmail.com",
    url='http://www.utng.edu.mx',
    py_modules=['ley_kepler']
)