from setuptools import setup

setup(
    name='kepler',
    version=1.2,
    description='This module calculate kepler',
    author='JDLV',
    author_email="jdlv@gmail.com",
    url='http://www.utng.edu.mx',
    py_modules=['ley_kepler']
)